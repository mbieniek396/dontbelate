export default [
    {
        "id": 1126,
        "name": "8 Maja",
        "lon": 17.091098,
        "lat": 51.1135437
    },
    {
        "id": 563,
        "name": "8 Maja",
        "lon": 17.09111971,
        "lat": 51.11366919
    },
    {
        "id": 589,
        "name": "8 Maja",
        "lon": 17.09144204,
        "lat": 51.11360471
    },
    {
        "id": 1134,
        "name": "8 Maja",
        "lon": 17.09229129,
        "lat": 51.11355205
    },
    {
        "id": 931,
        "name": "Adamczewskich",
        "lon": 16.86953486,
        "lat": 51.12084396
    },
    {
        "id": 923,
        "name": "Adamczewskich",
        "lon": 16.86956157,
        "lat": 51.12095339
    },
    {
        "id": 882,
        "name": "Adamieckiego",
        "lon": 16.96299503,
        "lat": 51.07425917
    },
    {
        "id": 875,
        "name": "Adamieckiego",
        "lon": 16.96365272,
        "lat": 51.07328333
    },
    {
        "id": 1650,
        "name": "Aleja Architektów",
        "lon": 16.92851914,
        "lat": 51.13898109
    },
    {
        "id": 386,
        "name": "Aleja Architektów",
        "lon": 16.92885963,
        "lat": 51.13892608
    },
    {
        "id": 401,
        "name": "Aleja Architektów",
        "lon": 16.92905866,
        "lat": 51.13881871
    },
    {
        "id": 502,
        "name": "Aleja Pracy",
        "lon": 16.98525882,
        "lat": 51.09175299
    },
    {
        "id": 67,
        "name": "Aleja Pracy",
        "lon": 16.98537334,
        "lat": 51.0918696
    },
    {
        "id": 14,
        "name": "Aleja Pracy",
        "lon": 16.98641641,
        "lat": 51.09225862
    },
    {
        "id": 1219,
        "name": "Aleja Pracy",
        "lon": 16.98655581,
        "lat": 51.09128158
    },
    {
        "id": 494,
        "name": "Aleja Pracy",
        "lon": 16.98670185,
        "lat": 51.09138458
    }
]